import React from 'react'

export default function Footer() {
  return (

    <footer>
        <p>Conny Engelbrekts</p>
        <p>cool0300@student.miun.se</p>
      </footer>

  )
}
